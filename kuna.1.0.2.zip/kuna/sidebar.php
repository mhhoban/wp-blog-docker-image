<?php if ( is_active_sidebar( 'kuna-right-sidebar' ) ) { ?>
	<aside id="sidebar" class="col-md-3" role="complementary">
		<?php dynamic_sidebar( 'kuna-right-sidebar' ); ?>
	</aside>
<?php } ?>
